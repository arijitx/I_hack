## story_00914561
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03812903
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "six", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00055028
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04649138
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00832024
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "london", "price": "expensive"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07265875
* greet
 - utter_ask_howcanhelp
* inform{"people": "two", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02879216
* greet
 - utter_ask_howcanhelp
* inform{"people": "two", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04818543
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "madrid", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07401415
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07314254
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "madrid", "price": "expensive"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03179721
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00008968
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "people": "six", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01856430
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "london", "price": "expensive"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08076703
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "people": "two", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06422060
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00264703
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00660267
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02753259
* greet
 - utter_ask_howcanhelp
* inform{"price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00496705
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "people": "eight", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04071825
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02065778
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00350794
* greet
 - utter_ask_howcanhelp
* inform{"people": "two", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04824790
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "four", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08852263
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07460140
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "people": "eight", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07720463
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "people": "four", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07930584
* greet
 - utter_ask_howcanhelp
* inform{"people": "four", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06519313
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "people": "four"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03248462
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "eight", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08607862
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "london", "price": "moderate"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06360277
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "london", "people": "four"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03043652
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07408662
* greet
 - utter_ask_howcanhelp
* inform{"price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01743655
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05692561
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "people": "eight", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03068439
* greet
 - utter_ask_howcanhelp
* inform{"location": "london"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00749657
* greet
 - utter_ask_howcanhelp
* inform{"people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03380511
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "london", "price": "expensive"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06422073
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "london", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09031916
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01978688
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "madrid"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04854177
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "people": "eight", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01399547
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "people": "eight", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01912632
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "london"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04612031
* greet
 - utter_ask_howcanhelp
* inform{"price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06463518
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "bombay", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09999406
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "bombay", "people": "two"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01480014
* greet
 - utter_ask_howcanhelp
* inform{"price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09053690
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "paris"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03827935
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "madrid", "people": "eight"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02993258
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05416743
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07596709
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00797530
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "london", "people": "two"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00153088
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "paris", "price": "expensive"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07360837
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "rome"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06027650
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "people": "eight", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00760313
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "rome", "people": "four"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09866647
* greet
 - utter_ask_howcanhelp
* inform{"people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00624668
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "two", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09174227
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "madrid", "people": "eight"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02413435
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03736207
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02843759
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "rome", "people": "two"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07728797
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08999407
* greet
 - utter_ask_howcanhelp
* inform{"location": "london"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04855656
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "people": "four", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00252998
* greet
 - utter_ask_howcanhelp
* inform{"people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06289573
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07003503
* greet
 - utter_ask_howcanhelp
* inform{"price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04378975
* greet
 - utter_ask_howcanhelp
* inform{"people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01209067
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01411182
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "london"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08103150
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02467890
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "people": "two", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06829456
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "rome", "people": "two"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09351905
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08944879
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "bombay"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09232261
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02664959
* greet
 - utter_ask_howcanhelp
* inform{"price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05047322
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "bombay", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03993480
* greet
 - utter_ask_howcanhelp
* inform{"people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01984348
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04592751
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09107150
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07407088
* greet
 - utter_ask_howcanhelp
* inform{"people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09044014
* greet
 - utter_ask_howcanhelp
* inform{"people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06301857
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "paris"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04834267
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "people": "eight", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07308412
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08908895
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "people": "eight"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01289187
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01937563
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "bombay", "people": "six"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05088706
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09156236
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "two"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05268845
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay", "people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04910721
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09452611
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00319959
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05133868
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06452510
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "four", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"people": "eight"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08526348
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "bombay", "people": "four"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00282948
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "people": "eight", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06641526
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08859037
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "madrid", "people": "four"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00008217
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01023896
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04705724
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08574082
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "madrid"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09464717
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03114526
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "madrid"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00481967
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "people": "four"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05718942
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09924129
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "people": "two", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08654911
* greet
 - utter_ask_howcanhelp
* inform{"location": "london"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04622584
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07235737
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00196299
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03874811
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "four", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06072887
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08654334
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04109384
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00978965
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06840076
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "paris", "price": "moderate"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04239724
* greet
 - utter_ask_howcanhelp
* inform{"price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09090049
* greet
 - utter_ask_howcanhelp
* inform{"people": "four", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04363473
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00292739
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08844467
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06812665
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "madrid", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03851125
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09004962
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04062695
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "madrid", "price": "moderate"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04531146
* greet
 - utter_ask_howcanhelp
* inform{"people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08162169
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "people": "four"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01498425
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "london", "price": "expensive"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03900022
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01611465
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02776468
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "people": "six", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07116144
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09424206
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "people": "six", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00512103
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "people": "six", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06202913
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "people": "two", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08813673
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09506631
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "two", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02056193
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "london"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05553278
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "rome"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05646905
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "people": "eight", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06882697
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "paris"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05241672
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "people": "six"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05836751
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "four"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04721693
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "paris", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00770250
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05479819
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay", "people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00494816
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09635922
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00166850
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "people": "six", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09144866
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "rome", "people": "two"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07590883
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "four", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03361929
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "rome", "people": "eight"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07093964
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01995661
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "people": "four", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01795624
* greet
 - utter_ask_howcanhelp
* inform{"people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05316798
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06296526
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay", "people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05730166
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08611434
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "six", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05526723
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "two", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01980989
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08103236
* greet
 - utter_ask_howcanhelp
* inform{"price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07071838
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05407160
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "london", "people": "four"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07910601
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "london"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02307960
* greet
 - utter_ask_howcanhelp
* inform{"people": "two", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01749191
* greet
 - utter_ask_howcanhelp
* inform{"people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07420454
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "london"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01541159
* greet
 - utter_ask_howcanhelp
* inform{"people": "four", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08330167
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "london", "people": "six"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09407900
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02658648
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08761159
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "people": "eight", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09442789
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07218685
* greet
 - utter_ask_howcanhelp
* inform{"price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08699011
* greet
 - utter_ask_howcanhelp
* inform{"price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02841802
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03987178
* greet
 - utter_ask_howcanhelp
* inform{"price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00112984
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "people": "six", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07260710
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "people": "four", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01365930
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05120672
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04325128
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "people": "eight", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09917382
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "madrid"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07932481
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04779175
* greet
 - utter_ask_howcanhelp
* inform{"people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07923412
* greet
 - utter_ask_howcanhelp
* inform{"price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07688327
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "people": "four", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08050237
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00790432
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "people": "two", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05477857
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08723729
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02145941
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "people": "four"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02904309
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay", "people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01750267
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "eight", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08931260
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04239519
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09899499
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09451894
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "people": "four", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05371750
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay", "people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00501978
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09072588
* greet
 - utter_ask_howcanhelp
* inform{"people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04582314
* greet
 - utter_ask_howcanhelp
* inform{"people": "four", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02085011
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01486105
* greet
 - utter_ask_howcanhelp
* inform{"price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08346274
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06655353
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00487479
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08015903
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "people": "four", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04625807
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "paris", "people": "eight"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07380679
* greet
 - utter_ask_howcanhelp
* inform{"price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09277738
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06093387
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04892036
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01978796
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03821257
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "people": "eight"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02199982
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09541007
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03036720
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "people": "six"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01854820
* greet
 - utter_ask_howcanhelp
* inform{"people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06568898
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05649369
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "people": "four"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08843346
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05316570
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05358117
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09519635
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "rome", "price": "expensive"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09472164
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "london", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00615105
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00755596
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07083125
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05765099
* greet
 - utter_ask_howcanhelp
* inform{"people": "six", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03535337
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05644691
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay", "people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06674428
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "people": "four"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01726720
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05055076
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "london"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08970965
* greet
 - utter_ask_howcanhelp
* inform{"people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09352826
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "bombay"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05365523
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "rome", "price": "moderate"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06000199
* greet
 - utter_ask_howcanhelp
* inform{"price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04273838
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01270052
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "people": "six", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06071407
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "people": "two", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02586833
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "paris", "people": "four"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03374461
* greet
 - utter_ask_howcanhelp
* inform{"location": "london"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00320931
* greet
 - utter_ask_howcanhelp
* inform{"people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08849930
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "six"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01807635
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "four"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05866804
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00240913
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04740686
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09772586
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "london"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08676027
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "bombay", "people": "four"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02540704
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "paris", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06208724
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "rome", "people": "four"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06554752
* greet
 - utter_ask_howcanhelp
* inform{"people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09403074
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "people": "six", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03984404
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "people": "two", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05700104
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "six"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01064359
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "rome", "price": "moderate"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00317473
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "people": "eight", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01597569
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06659073
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "paris", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00435977
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "people": "six", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01048473
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09745793
* greet
 - utter_ask_howcanhelp
* inform{"people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02995684
* greet
 - utter_ask_howcanhelp
* inform{"people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01091743
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06153610
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05036312
* greet
 - utter_ask_howcanhelp
* inform{"price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02891253
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07783774
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "eight"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08930502
* greet
 - utter_ask_howcanhelp
* inform{"price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07255380
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05514290
* greet
 - utter_ask_howcanhelp
* inform{"price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01373980
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "people": "four"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00309685
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06964204
* greet
 - utter_ask_howcanhelp
* inform{"price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00813497
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "people": "four"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08033594
* greet
 - utter_ask_howcanhelp
* inform{"people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"people": "eight"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00567104
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "people": "six", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01150384
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "two", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05429965
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04071153
* greet
 - utter_ask_howcanhelp
* inform{"people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02008888
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "paris", "people": "eight"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09630554
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07725040
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "rome", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03551647
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03397670
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00056459
* greet
 - utter_ask_howcanhelp
* inform{"price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08479801
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04324212
* greet
 - utter_ask_howcanhelp
* inform{"people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02693697
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "bombay"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00287919
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07004549
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08705460
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "people": "two", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08036201
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "paris", "price": "moderate"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09331784
* greet
 - utter_ask_howcanhelp
* inform{"price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"people": "eight"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01094208
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09614535
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "paris", "people": "eight"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04907440
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "paris", "people": "two"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05190938
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06127194
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "london", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03531922
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00150625
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "people": "six", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08760628
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "rome", "people": "eight"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05825522
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05485352
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06152786
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "madrid", "price": "moderate"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03468744
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "bombay", "price": "expensive"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02483313
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay", "people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04524370
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "bombay", "people": "two"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08553699
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06155115
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "people": "six", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07396521
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "people": "two"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09218245
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "london", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00707850
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00625551
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "rome"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01995917
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00009611
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "six", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00407170
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "people": "four", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03224749
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01812983
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "london", "people": "two"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04374466
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "six", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07767341
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03973524
* greet
 - utter_ask_howcanhelp
* inform{"people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07812635
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "people": "eight", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06011722
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "four", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07613896
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00029804
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "rome", "people": "four"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02635044
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08291350
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06125512
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "two"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06576772
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01283865
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay", "people": "six", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03117569
* greet
 - utter_ask_howcanhelp
* inform{"people": "six", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03258323
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00339868
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "four", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07011583
* greet
 - utter_ask_howcanhelp
* inform{"people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06529306
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "london", "price": "moderate"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07934293
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "eight", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01340261
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05727944
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "eight", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08095602
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07744301
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "bombay"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06311913
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "eight", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00778945
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03264243
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "bombay", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00732555
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "four", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02579568
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "people": "six", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09576867
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "people": "four", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00679041
* greet
 - utter_ask_howcanhelp
* inform{"price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08288637
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01644532
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "london", "people": "four"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06698936
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "people": "six", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08064956
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03224212
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05627930
* greet
 - utter_ask_howcanhelp
* inform{"price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04981783
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay", "people": "eight", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04951933
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "rome", "people": "six"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06109731
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00804842
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "six", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09231986
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03435211
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "paris", "people": "eight"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05044915
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "people": "eight", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04320483
* greet
 - utter_ask_howcanhelp
* inform{"price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03272467
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00130318
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "people": "six", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06774200
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03569719
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "paris"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04415388
* greet
 - utter_ask_howcanhelp
* inform{"people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09663817
* greet
 - utter_ask_howcanhelp
* inform{"people": "six", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09140372
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04024668
* greet
 - utter_ask_howcanhelp
* inform{"price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02250911
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "rome", "people": "two"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07026439
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09025690
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08062978
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09012310
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "eight", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03226177
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07217864
* greet
 - utter_ask_howcanhelp
* inform{"people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06723191
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "people": "four", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09874308
* greet
 - utter_ask_howcanhelp
* inform{"people": "four", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07353530
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "people": "four", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01780813
* greet
 - utter_ask_howcanhelp
* inform{"price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09116360
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "people": "eight", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06478210
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "people": "four", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"people": "eight"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06428553
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08772874
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "paris", "price": "moderate"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08825416
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01226483
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05839985
* greet
 - utter_ask_howcanhelp
* inform{"people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07551950
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "people": "six", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09290570
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "rome", "people": "two"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00460044
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "people": "four"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08340994
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "two"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07040871
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09860021
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "people": "six", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00345785
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "paris", "price": "moderate"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08546539
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "paris", "price": "moderate"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02555736
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09181244
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05537251
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02959702
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05083411
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "madrid", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09748536
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "london"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09561957
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "rome", "people": "two"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05700339
* greet
 - utter_ask_howcanhelp
* inform{"people": "four", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08358757
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "rome", "price": "moderate"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03651428
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "rome", "people": "four"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08265138
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04662800
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "two", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03897194
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "paris", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08275525
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04053749
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "madrid", "people": "six"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03563777
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08121610
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "paris", "people": "two"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00749297
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01653073
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "people": "eight", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02597905
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"people": "eight"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00952448
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "paris", "people": "six"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08262314
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "people": "six", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03645990
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay", "people": "eight", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07291868
* greet
 - utter_ask_howcanhelp
* inform{"people": "two", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09899206
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02191707
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08040444
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "paris"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04441788
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "bombay"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01260372
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01839285
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05525385
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01271574
* greet
 - utter_ask_howcanhelp
* inform{"people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03181821
* greet
 - utter_ask_howcanhelp
* inform{"price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03876284
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "madrid", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01452194
* greet
 - utter_ask_howcanhelp
* inform{"price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00156552
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04206739
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "people": "six", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00839949
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "people": "four", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09007272
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "london", "price": "moderate"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07334460
* greet
 - utter_ask_howcanhelp
* inform{"people": "two", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05216830
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "people": "eight", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00519879
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04577592
* greet
 - utter_ask_howcanhelp
* inform{"price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03590482
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03492103
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06001770
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "people": "eight", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05772832
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "people": "two"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04383021
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "paris", "people": "four"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04240637
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01854146
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "people": "six", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08385321
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01146386
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03529821
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07870026
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "people": "eight"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05488816
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06180843
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09241640
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08821976
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06840821
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06578239
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay", "people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07696073
* greet
 - utter_ask_howcanhelp
* inform{"price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08574664
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04972497
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "madrid", "people": "six"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09572174
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02168130
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "people": "four"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08170687
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09650629
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07085793
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "madrid", "people": "six"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00808985
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "paris"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06805887
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09229085
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "two"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07072585
* greet
 - utter_ask_howcanhelp
* inform{"people": "four", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05234126
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01604746
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "london", "people": "two"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01455955
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04008931
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "london", "people": "six"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05447297
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08821946
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00466675
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "bombay", "price": "expensive"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02593170
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "paris"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05062698
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "paris", "price": "moderate"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01070654
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00034683
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01264328
* greet
 - utter_ask_howcanhelp
* inform{"location": "london"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03535906
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "people": "six", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06889283
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01906313
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "people": "four"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00711706
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "people": "six", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"people": "eight"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09784883
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07815326
* greet
 - utter_ask_howcanhelp
* inform{"people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06473770
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "bombay"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01814609
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05455518
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "paris", "price": "moderate"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01305557
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "people": "six", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06484471
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09089141
* greet
 - utter_ask_howcanhelp
* inform{"price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05557115
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08149316
* greet
 - utter_ask_howcanhelp
* inform{"price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02242155
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "two", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04769285
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "people": "four"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09146248
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00536652
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "six", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07964398
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "people": "six", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00251195
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06556520
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "rome"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08164795
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03095701
* greet
 - utter_ask_howcanhelp
* inform{"people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07129734
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02504254
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "six"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03079768
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "london", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04764846
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay", "people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04549426
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "bombay"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04845907
* greet
 - utter_ask_howcanhelp
* inform{"people": "four", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09501145
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "six", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04887912
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "paris", "price": "moderate"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09815825
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay", "people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"people": "eight"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00365957
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "two", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02128834
* greet
 - utter_ask_howcanhelp
* inform{"people": "four", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00895793
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "london"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00156329
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06823684
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03189716
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "people": "six", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06677556
* greet
 - utter_ask_howcanhelp
* inform{"people": "four", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09834580
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "london", "price": "expensive"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03043608
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "madrid"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01080107
* greet
 - utter_ask_howcanhelp
* inform{"people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00309451
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00750605
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "bombay", "people": "six"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01959352
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00844474
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "people": "four", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08918527
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02712266
* greet
 - utter_ask_howcanhelp
* inform{"price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03217729
* greet
 - utter_ask_howcanhelp
* inform{"price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09971189
* greet
 - utter_ask_howcanhelp
* inform{"people": "four", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05683202
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "people": "six"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08055076
* greet
 - utter_ask_howcanhelp
* inform{"price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05409864
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02675405
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09905940
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01114266
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "people": "four", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09197344
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02195594
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "people": "six", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08441847
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01259421
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03028201
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09735512
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02969153
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07861584
* greet
 - utter_ask_howcanhelp
* inform{"price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01861546
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "rome", "price": "expensive"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02143971
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "people": "six", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00844567
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02272099
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "london"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00781021
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03902588
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04992470
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06482833
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07258658
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08776751
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "madrid", "people": "two"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05340573
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01263649
* greet
 - utter_ask_howcanhelp
* inform{"people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04161709
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07467763
* greet
 - utter_ask_howcanhelp
* inform{"price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00568872
* greet
 - utter_ask_howcanhelp
* inform{"people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02622089
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "people": "two"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06239058
* greet
 - utter_ask_howcanhelp
* inform{"people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04950138
* greet
 - utter_ask_howcanhelp
* inform{"price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02428348
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02512396
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "people": "four", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07176272
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "people": "eight", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02965882
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "people": "six"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00458333
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08889369
* greet
 - utter_ask_howcanhelp
* inform{"people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09904271
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "bombay", "price": "moderate"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07337015
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "paris", "people": "eight"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09964423
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04430664
* greet
 - utter_ask_howcanhelp
* inform{"price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02061383
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "people": "six", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08368858
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "paris", "price": "expensive"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06865110
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "people": "eight", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04755349
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08653684
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "people": "six"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06782231
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay", "people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00524308
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00933108
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "people": "eight", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09816555
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "people": "six"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06781617
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "people": "eight", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01160443
* greet
 - utter_ask_howcanhelp
* inform{"people": "two", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04244380
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "paris", "people": "six"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00849025
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "london"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06603544
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "people": "eight", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09753029
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03874013
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09085199
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03142136
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02365589
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "people": "four"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09744970
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07472413
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"people": "eight"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08186840
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay", "people": "eight", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08063971
* greet
 - utter_ask_howcanhelp
* inform{"people": "four", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00624478
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "rome", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04427174
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"people": "eight"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05484960
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "paris"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02449624
* greet
 - utter_ask_howcanhelp
* inform{"price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03439017
* greet
 - utter_ask_howcanhelp
* inform{"people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07255272
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "paris", "price": "moderate"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03604699
* greet
 - utter_ask_howcanhelp
* inform{"people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09860386
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04062984
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03941254
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "bombay", "people": "four"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00171217
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "madrid", "people": "six"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06811483
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01877039
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00969777
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03983773
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "six", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09662563
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06031304
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "eight", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06667107
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07420764
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01886993
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "paris", "price": "moderate"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07703774
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09421887
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02826756
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "people": "four"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00118580
* greet
 - utter_ask_howcanhelp
* inform{"people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04773474
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "madrid", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00776014
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04905103
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "paris"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04072855
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01706941
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00303134
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "madrid", "people": "four"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01385833
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "rome", "price": "moderate"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02725173
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05444359
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "people": "two"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04820873
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04166050
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08464725
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09530558
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01399039
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "six", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05254905
* greet
 - utter_ask_howcanhelp
* inform{"price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09668676
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05372829
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03066118
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05113464
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01865268
* greet
 - utter_ask_howcanhelp
* inform{"people": "six", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03632414
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "people": "eight", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02423947
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "people": "eight"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07713696
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08704162
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "people": "two", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03562838
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09822341
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"people": "eight"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06505143
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "rome", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00450317
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03676706
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06255358
* greet
 - utter_ask_howcanhelp
* inform{"location": "london"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09628610
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "madrid", "price": "expensive"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08373112
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "people": "eight"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03628824
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "london", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05225970
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06496178
* greet
 - utter_ask_howcanhelp
* inform{"people": "two", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02623324
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "paris"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05818644
* greet
 - utter_ask_howcanhelp
* inform{"people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08101371
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "madrid", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03320883
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "people": "eight", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06821629
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "bombay"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03159066
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00734264
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07777621
* greet
 - utter_ask_howcanhelp
* inform{"price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04252545
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06024388
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "madrid"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06714841
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "people": "eight", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08129380
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01172047
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06439574
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "people": "eight", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00593551
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "london", "people": "four"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02428697
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06510143
* greet
 - utter_ask_howcanhelp
* inform{"people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09073912
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03631655
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01208285
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "people": "eight"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05275649
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "bombay"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00789633
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09606751
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09656886
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "people": "eight", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00830863
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "paris", "price": "moderate"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07537213
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "people": "four"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09314942
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "madrid", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08940771
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09043068
* greet
 - utter_ask_howcanhelp
* inform{"price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03290139
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08852898
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "people": "four"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05740152
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "madrid", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06058369
* greet
 - utter_ask_howcanhelp
* inform{"price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00152569
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "people": "two", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09811824
* greet
 - utter_ask_howcanhelp
* inform{"price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00957490
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00919373
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "people": "two", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07279664
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04854964
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "people": "two"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00980793
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "paris", "people": "eight"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01065431
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01321177
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06376839
* greet
 - utter_ask_howcanhelp
* inform{"location": "london"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01929540
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06506308
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay", "people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04181925
* greet
 - utter_ask_howcanhelp
* inform{"people": "six", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00709765
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00938138
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00638016
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "people": "four", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05850607
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02751982
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay", "people": "six", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04296137
* greet
 - utter_ask_howcanhelp
* inform{"price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04876842
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "london", "people": "two"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07171758
* greet
 - utter_ask_howcanhelp
* inform{"price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08485578
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "madrid", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01314086
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "paris", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03724124
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06585817
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "paris", "people": "six"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00187798
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01933633
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay", "people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07144106
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "bombay"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05615854
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "people": "six"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05206907
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "bombay", "people": "eight"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09625580
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "people": "four"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03118434
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "london", "people": "six"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04889196
* greet
 - utter_ask_howcanhelp
* inform{"location": "london"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05274495
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04636405
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07145375
* greet
 - utter_ask_howcanhelp
* inform{"price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03694903
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "paris", "price": "expensive"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08117383
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "paris"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01220821
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "rome", "price": "expensive"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00893195
* greet
 - utter_ask_howcanhelp
* inform{"price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01317886
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03348323
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "people": "six", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07533049
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07826987
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08516839
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02817336
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09089819
* greet
 - utter_ask_howcanhelp
* inform{"people": "four", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03497250
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "madrid", "people": "four"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09330259
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "paris", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08349832
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09157416
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00131261
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay", "people": "eight", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06076209
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04570409
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "rome", "people": "eight"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06805619
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00022643
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "rome", "people": "two"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04937786
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "six", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06976592
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "london"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08424159
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09234537
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "london"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09862495
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05126643
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03337938
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "six", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03156665
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "paris"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02957865
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00349487
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "paris", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06798659
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "rome"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09813964
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "people": "four", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05131495
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "london", "people": "two"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07895394
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08823894
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "people": "six", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09702036
* greet
 - utter_ask_howcanhelp
* inform{"location": "london"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02282032
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "bombay", "people": "two"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01130224
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00895499
* greet
 - utter_ask_howcanhelp
* inform{"price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02600877
* greet
 - utter_ask_howcanhelp
* inform{"price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03949551
* greet
 - utter_ask_howcanhelp
* inform{"price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04176053
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "four", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"people": "eight"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08679366
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01552180
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "madrid", "people": "six"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01393050
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01233425
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "london", "people": "two"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00898140
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "four", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00902206
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "six", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08674334
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "london", "people": "two"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05505791
* greet
 - utter_ask_howcanhelp
* inform{"price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04410049
* greet
 - utter_ask_howcanhelp
* inform{"price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05972136
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08344798
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "people": "eight"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04798183
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06230240
* greet
 - utter_ask_howcanhelp
* inform{"location": "london"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01434051
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01094264
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00393178
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "people": "four"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08422070
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "bombay", "people": "six"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09244706
* greet
 - utter_ask_howcanhelp
* inform{"people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06328099
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "people": "two"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04284245
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "bombay"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05686914
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "london"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08073789
* greet
 - utter_ask_howcanhelp
* inform{"people": "four", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04518461
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08600837
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "madrid", "people": "two"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08425819
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00469483
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "rome", "people": "two"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09908909
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02726499
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "madrid"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00122274
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "people": "four", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04605461
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01127782
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07047906
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05382785
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09951364
* greet
 - utter_ask_howcanhelp
* inform{"location": "london"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07714658
* greet
 - utter_ask_howcanhelp
* inform{"people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05753493
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "rome", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02319303
* greet
 - utter_ask_howcanhelp
* inform{"people": "two", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03053117
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08039509
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"people": "eight"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06063036
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01842291
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "paris", "price": "expensive"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00404771
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06303012
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08826114
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08580853
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "madrid", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03270022
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06783355
* greet
 - utter_ask_howcanhelp
* inform{"people": "four", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00816632
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04796764
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "london"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07985063
* greet
 - utter_ask_howcanhelp
* inform{"price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09178086
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "madrid"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01643031
* greet
 - utter_ask_howcanhelp
* inform{"location": "london"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09604583
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "bombay"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07887953
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "madrid", "price": "moderate"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09163759
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05195314
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "madrid"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06757748
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "people": "two", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06250942
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09472081
* greet
 - utter_ask_howcanhelp
* inform{"price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07167680
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06327458
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "people": "two"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09740907
* greet
 - utter_ask_howcanhelp
* inform{"price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01812192
* greet
 - utter_ask_howcanhelp
* inform{"location": "london"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04856578
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04325428
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "eight", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01398241
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04724172
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "people": "eight"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07606335
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05715031
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "people": "two", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05296588
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08104850
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05853971
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04727618
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "london"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01711241
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "people": "eight", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03936603
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "people": "four", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08576952
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "london"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04804222
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00268133
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07483909
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06777191
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02494821
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00239185
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "people": "four", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04801990
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06766036
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "four"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06440930
* greet
 - utter_ask_howcanhelp
* inform{"people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02380468
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "eight", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04005855
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "people": "four", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07405507
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "paris"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00498578
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00109081
* greet
 - utter_ask_howcanhelp
* inform{"price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04689909
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "people": "four", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01583175
* greet
 - utter_ask_howcanhelp
* inform{"people": "four", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06081230
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09650700
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08683423
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "rome"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09809140
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08704448
* greet
 - utter_ask_howcanhelp
* inform{"price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05846298
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01001501
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08879496
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "people": "four", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07666308
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07775524
* greet
 - utter_ask_howcanhelp
* inform{"price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06657612
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03634704
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "bombay"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09374425
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03996025
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "madrid"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09354384
* greet
 - utter_ask_howcanhelp
* inform{"people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05281037
* greet
 - utter_ask_howcanhelp
* inform{"price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00319688
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06274716
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "paris"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00091875
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03406779
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05395046
* greet
 - utter_ask_howcanhelp
* inform{"people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04030638
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08550472
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "paris", "people": "two"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07104468
* greet
 - utter_ask_howcanhelp
* inform{"people": "six", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07688540
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01518753
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "six", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09864436
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "people": "two", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04577171
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09610292
* greet
 - utter_ask_howcanhelp
* inform{"people": "four", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03166920
* greet
 - utter_ask_howcanhelp
* inform{"price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03469112
* greet
 - utter_ask_howcanhelp
* inform{"people": "four", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06962015
* greet
 - utter_ask_howcanhelp
* inform{"price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00278172
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08966504
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "madrid", "price": "moderate"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02470749
* greet
 - utter_ask_howcanhelp
* inform{"people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04454934
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05034229
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00180528
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "bombay", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08515298
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06859902
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00392312
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "paris", "people": "two"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05725205
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07300290
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "people": "four", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06309353
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "people": "six", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03854799
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "people": "six", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09566883
* greet
 - utter_ask_howcanhelp
* inform{"people": "two", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01043845
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00253574
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03763786
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "london", "price": "expensive"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02144977
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09850809
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09163022
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "london"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07274687
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08837527
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "bombay", "price": "moderate"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00921838
* greet
 - utter_ask_howcanhelp
* inform{"people": "four"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05904994
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08347700
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "paris", "price": "moderate"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06500049
* greet
 - utter_ask_howcanhelp
* inform{"people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02620391
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "paris", "price": "expensive"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09116560
* greet
 - utter_ask_howcanhelp
* inform{"people": "six", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09270102
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "madrid", "price": "expensive"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06726927
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09168519
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "london", "price": "expensive"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09385493
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "paris", "price": "moderate"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01287768
* greet
 - utter_ask_howcanhelp
* inform{"people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01543338
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02541285
* greet
 - utter_ask_howcanhelp
* inform{"people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09271185
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "london"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00367264
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "people": "four", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04229414
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "people": "four"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08134123
* greet
 - utter_ask_howcanhelp
* inform{"people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03235504
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "bombay", "people": "two"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03978119
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "paris", "price": "expensive"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09361073
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "people": "two", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03261321
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "london", "people": "four"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00496996
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06118884
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "people": "six", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08182507
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00422529
* greet
 - utter_ask_howcanhelp
* inform{"location": "london"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "two"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03013594
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "people": "two"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09008945
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03370167
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04723733
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02172992
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04436511
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07834269
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08319983
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "four"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06524055
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06490936
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03364039
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "location": "madrid", "people": "six"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03853664
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06995338
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "people": "two", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09243427
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "london", "people": "four"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01653797
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "paris", "people": "four"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03279828
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09879267
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04204187
* greet
 - utter_ask_howcanhelp
* inform{"people": "eight"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* inform{"location": "london"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00656127
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay", "price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "italian"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "french"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02034035
* greet
 - utter_ask_howcanhelp
* inform{"location": "london", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07316004
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "london", "price": "moderate"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03687127
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "price": "expensive"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03560336
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09441270
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "london", "price": "cheap"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01872699
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "two", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02048330
* greet
 - utter_ask_howcanhelp
* inform{"price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "eight"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"location": "rome"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06319392
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09516193
* greet
 - utter_ask_howcanhelp
* inform{"location": "madrid", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02657528
* greet
 - utter_ask_howcanhelp
* inform{"location": "bombay", "people": "two"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00310392
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"location": "paris"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04983227
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "rome", "price": "moderate"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_09239368
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "french"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_01412677
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "location": "paris", "people": "four"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "spanish"}
 - utter_ask_moreupdates
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03771921
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "location": "london", "people": "four"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02587073
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "paris"}
 - utter_on_it
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04309861
* greet
 - utter_ask_howcanhelp
* inform{"price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05490968
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "people": "six"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "london"}
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_00145741
* greet
 - utter_ask_howcanhelp
* inform{"location": "rome", "people": "eight", "price": "expensive"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05547840
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_04527193
* greet
 - utter_ask_howcanhelp
* inform{"location": "paris", "people": "four", "price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03326363
* greet
 - utter_ask_howcanhelp
* inform{"people": "six"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08338160
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "spanish", "people": "six", "price": "moderate"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08226375
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "british", "location": "london", "people": "six"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "cheap"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07961733
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "madrid"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "moderate"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* inform{"people": "six"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02606355
* greet
 - utter_ask_howcanhelp
* inform{"price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "spanish"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "eight"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "madrid"}
 - utter_ask_moreupdates
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"cuisine": "british"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_06093780
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "four"}
 - utter_ask_price
* inform{"price": "expensive"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07143287
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "french", "people": "four", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "bombay"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* inform{"people": "two"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_03162809
* greet
 - utter_ask_howcanhelp
* inform{"price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_ask_location
* inform{"location": "paris"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_02589793
* greet
 - utter_ask_howcanhelp
* inform{"price": "moderate"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"people": "six"}
 - utter_ask_moreupdates
* inform{"cuisine": "italian"}
 - utter_ask_moreupdates
* inform{"location": "bombay"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_08740741
* greet
 - utter_ask_howcanhelp
* inform{"price": "cheap"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "british"}
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "six"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"location": "paris"}
 - utter_ask_moreupdates
* inform{"price": "expensive"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_05389447
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "italian", "location": "rome", "people": "eight"}
 - utter_on_it
 - utter_ask_price
* inform{"price": "cheap"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"cuisine": "indian"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "phone"}
 - action_suggest
* request_info{"info": "address"}
 - action_suggest
* thankyou
 - utter_ask_helpmore

## story_07621761
* greet
 - utter_ask_howcanhelp
* inform{"cuisine": "indian", "price": "cheap"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "rome"}
 - utter_ask_numpeople
* inform{"people": "two"}
 - utter_ack_dosearch
 - action_search_restaurants
* inform{"price": "moderate"}
 - utter_ask_moreupdates
* inform{"people": "four"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
* greet
 - utter_ack_findalternatives
 - action_suggest
* deny
 - utter_ack_findalternatives
 - action_suggest
* affirm
 - utter_ack_makereservation
* request_info{"info": "address"}
 - action_suggest
* request_info{"info": "phone"}
 - action_suggest
* thankyou
 - utter_ask_helpmore
## story_00915479
* greet
 - utter_ask_howcanhelp
* inform{"people":"five"}
 - utter_on_it
 - utter_ask_cuisine
* inform{"cuisine": "indian"}
 - utter_on_it
 - utter_ask_location
* inform{"location": "delhi"}
 - utter_ask_moreupdates
* deny
 - utter_ack_dosearch
 - action_search_restaurants
 - action_suggest
